.. _release-notes:

Release notes
=============

The |version| release of |project| supports Python 2.7, 3.4, 3.5, 3.6, 3.7 and
Django 1.11, 2.0, 2.1, and 2.2.
